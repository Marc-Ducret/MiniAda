package net.slimevoid.miniada.token;

public class EOF extends Yytoken {
	@Override
	public String toString() {
		return "@eof";
	}
}
