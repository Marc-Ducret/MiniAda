package net.slimevoid.miniada.execution;

public interface ASMOperand {
	
	public void appendToBuilder(StringBuilder buff);
}
