package net.slimevoid.miniada.execution;

public class LocalExecuter extends Executer {

	@Override
	public String execute(String asm) {
		return null;
	}

}
