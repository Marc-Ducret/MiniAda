package net.slimevoid.miniada.execution;

public class ASMConst implements ASMOperand {

	public ASMConst(int i) {
	}

	@Override
	public void appendToBuilder(StringBuilder buff) {
		// TODO Auto-generated method stub
		//TODO do
	}

}
