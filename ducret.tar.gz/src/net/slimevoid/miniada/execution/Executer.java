package net.slimevoid.miniada.execution;

public abstract class Executer {

	public abstract String execute(String asm) 
			throws ExecutionException;
}
