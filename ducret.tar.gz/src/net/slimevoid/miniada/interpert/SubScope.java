package net.slimevoid.miniada.interpert;

public class SubScope extends Scope {

	@SuppressWarnings("unused")
	private final Scope parent;
	
	public SubScope(Scope parent) {
		this.parent = parent;
	}
	
	//TODO do....
}
